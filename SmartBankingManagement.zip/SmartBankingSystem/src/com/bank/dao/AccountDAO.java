package com.bank.dao;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import com.bank.util.DBConnection;
import com.bank.model.Account;
import com.bank.util.DBConnection;
import javax.swing.JOptionPane;

public class AccountDAO {

    public void createAccount(Account account) {

        try {
            Connection con = DBConnection.getConnection();

            String query = "INSERT INTO account(customer_id,balance,account_type) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, account.getCustomerId());
            ps.setDouble(2, account.getBalance());
            ps.setString(3, account.getAccountType());

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Account Created Successfully!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void depositMoney(int accountNo, double amount) {

        try {
            Connection con = DBConnection.getConnection();

            String query =
                    "UPDATE account SET balance = balance + ? WHERE account_no = ?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setDouble(1, amount);
            ps.setInt(2, accountNo);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Deposit Successful!");
                saveTransaction(accountNo, "Deposit", amount);
            } else {
                System.out.println("Account Not Found!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void withdrawMoney(int accountNo, double amount) {

        try {
            Connection con = DBConnection.getConnection();

            String query =
                "UPDATE account SET balance = balance - ? " +
                "WHERE account_no = ? AND balance >= ?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setDouble(1, amount);
            ps.setInt(2, accountNo);
            ps.setDouble(3, amount);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Money Withdrawn Successfully!");
                saveTransaction(accountNo, "Withdraw", amount);
            } else {
                System.out.println("Insufficient Balance or Account Not Found!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void checkBalance(int accountNo) {

        try {

            Connection con = DBConnection.getConnection();

            String query = "SELECT balance FROM account WHERE account_no=?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, accountNo);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {

                JOptionPane.showMessageDialog(null,
                        "Current Balance : " + rs.getDouble("balance"));

            } else {

                JOptionPane.showMessageDialog(null,
                        "Account Not Found!");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    public void transferMoney(int fromAcc, int toAcc, double amount) {

        try {
            Connection con = DBConnection.getConnection();

            con.setAutoCommit(false);

            String withdraw =
                    "UPDATE account SET balance = balance - ? " +
                    "WHERE account_no = ? AND balance >= ?";

            PreparedStatement ps1 = con.prepareStatement(withdraw);

            ps1.setDouble(1, amount);
            ps1.setInt(2, fromAcc);
            ps1.setDouble(3, amount);

            int rows = ps1.executeUpdate();

            if(rows > 0) {

                String deposit =
                        "UPDATE account SET balance = balance + ? " +
                        "WHERE account_no = ?";

                PreparedStatement ps2 = con.prepareStatement(deposit);

                ps2.setDouble(1, amount);
                ps2.setInt(2, toAcc);

                ps2.executeUpdate();

                con.commit();

                System.out.println("Transfer Successful!");
                saveTransaction(fromAcc, "Transfer", amount);
            }
            else {
                con.rollback();
                System.out.println("Insufficient Balance!");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    public void saveTransaction(int accountNo, String type, double amount) {

        try {
            Connection con = DBConnection.getConnection();

            String query =
                "INSERT INTO transaction_history(account_no, transaction_type, amount) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, accountNo);
            ps.setString(2, type);
            ps.setDouble(3, amount);

            ps.executeUpdate();

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    public void miniStatement(int accountNo) {

        try {

            Connection con = DBConnection.getConnection();

            String query =
            "SELECT * FROM transaction_history " +
            "WHERE account_no=? " +
            "ORDER BY transaction_id DESC LIMIT 5";

            PreparedStatement ps =
                    con.prepareStatement(query);

            ps.setInt(1, accountNo);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                System.out.println(
                    rs.getInt("transaction_id") + " | " +
                    rs.getString("transaction_type") + " | " +
                    rs.getDouble("amount") + " | " +
                    rs.getTimestamp("transaction_date")
                );
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    public void searchAccount(int accountNo) {

        try {

            Connection con = DBConnection.getConnection();

            String query =
                "SELECT * FROM account WHERE account_no=?";

            PreparedStatement ps =
                    con.prepareStatement(query);

            ps.setInt(1, accountNo);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {

                System.out.println(
                    "Account No : " + rs.getInt("account_no"));

                System.out.println(
                    "Customer ID : " + rs.getInt("customer_id"));

                System.out.println(
                    "Balance : " + rs.getDouble("balance"));

                System.out.println(
                    "Account Type : " + rs.getString("account_type"));

            } else {

                System.out.println("Account Not Found!");

            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
   
   
    public String getAllAccounts() {

        String data = "";

        try {
            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM account";

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while(rs.next()) {

                data += rs.getLong("account_no") + "   "
                     + rs.getInt("customer_id") + "   "
                     + rs.getString("account_type") + "   "
                     + rs.getDouble("balance") + "\n";
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return data;
    }
    public void deleteAccount(long accountNo) {

        try {
            Connection con = DBConnection.getConnection();

            String query = "DELETE FROM account WHERE account_no = ?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setLong(1, accountNo);

            int rows = ps.executeUpdate();

            if(rows > 0) {
                System.out.println("Account Deleted Successfully");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
        
    }
    public void updateAccount(Account account) {

        try {

            Connection con = DBConnection.getConnection();

            String query =
            "UPDATE account SET customer_id=?, account_type=?, balance=? WHERE account_no=?";

            PreparedStatement ps =
            con.prepareStatement(query);

            ps.setInt(1, account.getCustomerId());
            ps.setString(2, account.getAccountType());
            ps.setDouble(3, account.getBalance());
            ps.setLong(4, account.getAccountNo());

            int rows = ps.executeUpdate();

            if(rows > 0) {
                System.out.println("Account Updated Successfully");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    public String getTransactionHistory() {

        String data = "";

        try {

            Connection con = DBConnection.getConnection();

            String query =
            "SELECT * FROM transaction_history";

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(query);

            while(rs.next()) {

                data += rs.getInt("transaction_id")
                     + " | "
                     + rs.getInt("account_no")
                     + " | "
                     + rs.getString("transaction_type")
                     + " | "
                     + rs.getDouble("amount")
                     + "\n";
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return data;
    }
    public String getTransactionHistory(int accountNo) {

        String data = "";

        try {

            Connection con = DBConnection.getConnection();

            String query =
            "SELECT * FROM transaction_history WHERE account_no=?";

            PreparedStatement ps =
            con.prepareStatement(query);

            ps.setInt(1, accountNo);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                data += rs.getInt("transaction_id")
                     + " | "
                     + rs.getString("transaction_type")
                     + " | "
                     + rs.getDouble("amount")
                     + "\n";
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return data;
    }
}
