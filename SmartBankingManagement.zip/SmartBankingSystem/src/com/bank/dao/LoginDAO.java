package com.bank.dao;
import com.bank.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDAO {

    public boolean login(String username, String password) {

        try {

            Connection con = DBConnection.getConnection();

            String query =
            "SELECT * FROM user_login WHERE username=? AND password=?";

            PreparedStatement ps =
                    con.prepareStatement(query);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            return rs.next(); 
            		
        } catch(Exception e) {
            e.printStackTrace();
        }

        return false;
    }
    public void changePassword(String username, String newPassword) {

        try {
            Connection con = DBConnection.getConnection();

            String query =
                "UPDATE user_login SET password=? WHERE username=?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, newPassword);
            ps.setString(2, username);

            int rows = ps.executeUpdate();

            if(rows > 0) {
                System.out.println("Password Changed Successfully!");
            } else {
                System.out.println("User Not Found!");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
