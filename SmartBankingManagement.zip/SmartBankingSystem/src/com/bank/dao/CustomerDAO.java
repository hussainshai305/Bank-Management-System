package com.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import com.bank.model.Customer;
import com.bank.util.DBConnection;

public class CustomerDAO {

    public void addCustomer(Customer customer) {

        try {
            Connection con = DBConnection.getConnection();

            String query = "INSERT INTO customer(customer_name,email, phone,balance) VALUES(?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, customer.getCustomerName());
            ps.setString(2,customer.getEmail());
            ps.setLong(3, customer.getPhone());
            ps.setDouble(4,customer.getBalance());

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Customer Added Successfully!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewCustomers() {
        try {
            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM customer";

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {
                System.out.println(
                    rs.getInt("customer_id") + " " +
                    rs.getString("customer_name") + " " +
                    rs.getString("email") + " " +
                    rs.getLong("phone")+" "+
                    rs.getDouble("balance")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void deleteCustomer(int id) {

        try {
            Connection con = DBConnection.getConnection();

            String query = "DELETE FROM customer WHERE customer_id = ?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Customer Deleted Successfully!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void updateCustomer(Customer customer) {

        try {
            Connection con = DBConnection.getConnection();

            String query = "UPDATE customer SET customer_name=?, email=?, phone=? WHERE customer_id=?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, customer.getCustomerName());
            ps.setString(2, customer.getEmail());
            ps.setLong(3, customer.getPhone());
            ps.setInt(4, customer.getCustomerId());

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Customer Updated Successfully!");
            } else {
                System.out.println("Customer ID Not Found!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public String getAllCustomers() {

        StringBuilder sb = new StringBuilder();

        try {

            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM customer";

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(query);

            while(rs.next()) {

                sb.append(rs.getInt("customer_id"))
                  .append(" | ")
                  .append(rs.getString("customer_name"))
                  .append(" | ")
                  .append(rs.getString("email"))
                  .append(" | ")
                  .append(rs.getLong("phone"))
                  .append("\n");

            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return sb.toString();
    }
}
