
package com.bank.util;


import java.sql.DriverManager;
	import java.sql.Connection;

	public class DBConnection {

	    public static Connection getConnection() {

	        Connection con = null;

	        try {
	            con = DriverManager.getConnection(
	                    "jdbc:mysql://localhost:3306/banking_system",
	                    "root",
	                    "Hussain@305");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return con;
	    }
	}

