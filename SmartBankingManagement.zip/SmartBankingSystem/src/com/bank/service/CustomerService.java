package com.bank.service;

import com.bank.dao.CustomerDAO;
import com.bank.model.Customer;

public class CustomerService {

    CustomerDAO dao = new CustomerDAO();

    public void addCustomer(Customer customer) {
        dao.addCustomer(customer);
    }

    public void viewCustomers() {
        dao.viewCustomers();
    }

    public void updateCustomer(Customer customer) {
        dao.updateCustomer(customer);
    }

    public void deleteCustomer(int id) {
        dao.deleteCustomer(id);
    }
}
