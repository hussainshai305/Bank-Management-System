package com.bank.service;

import com.bank.dao.AccountDAO;

public class AccountService {

    AccountDAO dao = new AccountDAO();

    public void deposit(int accountNo, double amount) {
        dao.depositMoney(accountNo, amount);
    }

    public void withdraw(int accountNo, double amount) {
        dao.withdrawMoney(accountNo, amount);
    }

    public void checkBalance(int accountNo) {
        dao.checkBalance(accountNo);
    }

    public void transfer(int fromAcc, int toAcc, double amount) {
        dao.transferMoney(fromAcc, toAcc, amount);
    }
}
