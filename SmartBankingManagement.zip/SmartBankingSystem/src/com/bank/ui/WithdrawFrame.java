package com.bank.ui;

import javax.swing.*;
import com.bank.dao.AccountDAO;

public class WithdrawFrame {

    public WithdrawFrame() {

        JFrame frame = new JFrame("Withdraw Money");

        JLabel accLabel = new JLabel("Account No:");
        accLabel.setBounds(50, 50, 100, 30);

        JTextField accField = new JTextField();
        accField.setBounds(150, 50, 150, 30);

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setBounds(50, 100, 100, 30);

        JTextField amountField = new JTextField();
        amountField.setBounds(150, 100, 150, 30);

        JButton withdrawBtn = new JButton("Withdraw");
        withdrawBtn.setBounds(150, 160, 100, 30);

        withdrawBtn.addActionListener(e -> {

            int accountNo =
                    Integer.parseInt(accField.getText());

            double amount =
                    Double.parseDouble(amountField.getText());

            AccountDAO dao = new AccountDAO();

            dao.withdrawMoney(accountNo, amount);

            JOptionPane.showMessageDialog(frame,
                    "Withdraw Successful");
        });

        frame.add(accLabel);
        frame.add(accField);
        frame.add(amountLabel);
        frame.add(amountField);
        frame.add(withdrawBtn);

        frame.setLayout(null);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
