package com.bank.ui;
import com.bank.main.LoginFrame;
import javax.swing.*;
import com.bank.ui.CustomerFrame;

public class DashboardFrame {

    public DashboardFrame() {

        JFrame frame = new JFrame("Smart Banking System");

        JButton customerBtn = new JButton("Customer Management");
        customerBtn.setBounds(100, 50, 200, 30);

        JButton accountBtn = new JButton("Account Management");
        accountBtn.setBounds(100, 100, 200, 30);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(100, 150, 200, 30);

        frame.add(customerBtn);
        frame.add(accountBtn);
        frame.add(logoutBtn);
        
        customerBtn.addActionListener(e -> {
            new CustomerFrame();
        });

        accountBtn.addActionListener(e -> {
            new AccountFrame();
        });

        logoutBtn.addActionListener(e -> {
            frame.dispose();
            new LoginFrame();
        });
        accountBtn.addActionListener(e -> {
            new AccountFrame();
        });

        frame.setLayout(null);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
