package com.bank.ui;

import javax.swing.*;
import com.bank.dao.AccountDAO;

public class TransferFrame {

    public TransferFrame() {

        JFrame frame = new JFrame("Transfer Money");

        JLabel fromLabel = new JLabel("From Account:");
        fromLabel.setBounds(50, 50, 100, 30);

        JTextField fromField = new JTextField();
        fromField.setBounds(170, 50, 150, 30);

        JLabel toLabel = new JLabel("To Account:");
        toLabel.setBounds(50, 100, 100, 30);

        JTextField toField = new JTextField();
        toField.setBounds(170, 100, 150, 30);

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setBounds(50, 150, 100, 30);

        JTextField amountField = new JTextField();
        amountField.setBounds(170, 150, 150, 30);

        JButton transferBtn = new JButton("Transfer");
        transferBtn.setBounds(120, 220, 120, 30);

        transferBtn.addActionListener(e -> {

            int fromAcc = Integer.parseInt(fromField.getText());
            int toAcc = Integer.parseInt(toField.getText());
            double amount = Double.parseDouble(amountField.getText());

            AccountDAO dao = new AccountDAO();
            dao.transferMoney(fromAcc, toAcc, amount);

            JOptionPane.showMessageDialog(null,
                    "Transfer Process Completed");
        });

        frame.add(fromLabel);
        frame.add(fromField);
        frame.add(toLabel);
        frame.add(toField);
        frame.add(amountLabel);
        frame.add(amountField);
        frame.add(transferBtn);

        frame.setLayout(null);
        frame.setSize(400, 350);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
