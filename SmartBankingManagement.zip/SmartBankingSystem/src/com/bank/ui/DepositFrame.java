package com.bank.ui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.bank.dao.AccountDAO;

public class DepositFrame {

	public DepositFrame() {

		JFrame frame = new JFrame("Deposit Money");

		JLabel accLabel = new JLabel("Account No:");
		accLabel.setBounds(50, 50, 100, 30);

		JTextField accField = new JTextField();
		accField.setBounds(150, 50, 150, 30);

		JLabel amountLabel = new JLabel("Amount:");
		amountLabel.setBounds(50, 100, 100, 30);

		JTextField amountField = new JTextField();
		amountField.setBounds(150, 100, 150, 30);

		JButton depositBtn = new JButton("Deposit");
		depositBtn.setBounds(150, 160, 100, 30);

		depositBtn.addActionListener(e -> {

			int accountNo = Integer.parseInt(accField.getText());

			double amount = Double.parseDouble(amountField.getText());

			AccountDAO dao = new AccountDAO();

			dao.depositMoney(accountNo, amount);

			JOptionPane.showMessageDialog(frame, "Amount Deposited Successfully");
		});

		frame.add(accLabel);
		frame.add(accField);
		frame.add(amountLabel);
		frame.add(amountField);
		frame.add(depositBtn);

		frame.setLayout(null);
		frame.setSize(400, 300);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}
