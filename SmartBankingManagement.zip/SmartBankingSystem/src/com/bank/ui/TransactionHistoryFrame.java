package com.bank.ui;

import javax.swing.*;
import com.bank.dao.AccountDAO;

public class TransactionHistoryFrame {

    public TransactionHistoryFrame() {

        JFrame frame = new JFrame("Transaction History");

        JLabel label = new JLabel("Account No:");
        label.setBounds(50,50,100,30);

        JTextField accountField = new JTextField();
        accountField.setBounds(150,50,150,30);

        JButton showBtn = new JButton("Show History");
        showBtn.setBounds(120,100,150,30);

        JTextArea area = new JTextArea();

        JScrollPane pane = new JScrollPane(area);
        pane.setBounds(20,150,450,200);

        showBtn.addActionListener(e -> {

            int accountNo =
            Integer.parseInt(accountField.getText());

            AccountDAO dao = new AccountDAO();

            String data =
            dao.getTransactionHistory(accountNo);

            area.setText(data);
        });

        frame.add(label);
        frame.add(accountField);
        frame.add(showBtn);
        frame.add(pane);

        frame.setLayout(null);
        frame.setSize(500,450);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
