package com.bank.ui;

import javax.swing.*;
import com.bank.dao.AccountDAO;

public class BalanceEnquiryFrame {

    public BalanceEnquiryFrame() {

        JFrame frame = new JFrame("Balance Enquiry");

        JLabel accLabel = new JLabel("Account No:");
        accLabel.setBounds(50, 50, 100, 30);

        JTextField accField = new JTextField();
        accField.setBounds(150, 50, 150, 30);

        JButton checkBtn = new JButton("Check Balance");
        checkBtn.setBounds(120, 120, 150, 30);
        checkBtn.addActionListener(e -> {

            int accountNo =
                    Integer.parseInt(accField.getText());

            AccountDAO dao = new AccountDAO();

            dao.checkBalance(accountNo);

        });

        frame.add(accLabel);
        frame.add(accField);
        frame.add(checkBtn);

        frame.setLayout(null);
        frame.setSize(400, 250);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
