package com.bank.ui;

import javax.swing.*;
import com.bank.model.Account;
import com.bank.dao.AccountDAO;
public class AddAccountFrame {

    public AddAccountFrame() {

        JFrame frame = new JFrame("Add Account");

        JLabel accountNoLabel = new JLabel("Account No:");
        accountNoLabel.setBounds(50, 50, 100, 30);

        JTextField accountNoField = new JTextField();
        accountNoField.setBounds(150, 50, 150, 30);

        JLabel customerIdLabel = new JLabel("Customer ID:");
        customerIdLabel.setBounds(50, 100, 100, 30);

        JTextField customerIdField = new JTextField();
        customerIdField.setBounds(150, 100, 150, 30);

        JLabel typeLabel = new JLabel("Account Type:");
        typeLabel.setBounds(50, 150, 100, 30);

        JTextField typeField = new JTextField();
        typeField.setBounds(150, 150, 150, 30);

        JLabel balanceLabel = new JLabel("Balance:");
        balanceLabel.setBounds(50, 200, 100, 30);

        JTextField balanceField = new JTextField();
        balanceField.setBounds(150, 200, 150, 30);

        JButton saveBtn = new JButton("Save");
        saveBtn.setBounds(150, 260, 100, 30);
        saveBtn.addActionListener(e -> {

            long accountNo = Long.parseLong(accountNoField.getText());
            int customerId = Integer.parseInt(customerIdField.getText());
            String accountType = typeField.getText();
            double balance = Double.parseDouble(balanceField.getText());

            Account account = new Account();

            account.setAccountNo(accountNo);
            account.setCustomerId(customerId);
            account.setAccountType(accountType);
            account.setBalance(balance);

            AccountDAO dao = new AccountDAO();
            dao.createAccount(account);

            JOptionPane.showMessageDialog(frame,
                    "Account Added Successfully");

        });

        frame.add(accountNoLabel);
        frame.add(accountNoField);
        frame.add(customerIdLabel);
        frame.add(customerIdField);
        frame.add(typeLabel);
        frame.add(typeField);
        frame.add(balanceLabel);
        frame.add(balanceField);
        frame.add(saveBtn);

        frame.setLayout(null);
        frame.setSize(400, 350);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}