package com.bank.ui;
import javax.swing.*;
import com.bank.dao.CustomerDAO;
import com.bank.model.Customer;
public class AddCustomerFrame {

    public AddCustomerFrame() {

        JFrame frame = new JFrame("Add Customer");

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 50, 100, 30);

        JTextField nameField = new JTextField();
        nameField.setBounds(150, 50, 150, 30);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 100, 100, 30);

        JTextField emailField = new JTextField();
        emailField.setBounds(150, 100, 150, 30);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(50, 150, 100, 30);

        JTextField phoneField = new JTextField();
        phoneField.setBounds(150, 150, 150, 30);

        JButton saveBtn = new JButton("Save");
        saveBtn.setBounds(150, 220, 100, 30);

        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(phoneLabel);
        frame.add(phoneField);
        frame.add(saveBtn);
        saveBtn.addActionListener(e -> {

            String name = nameField.getText();
            String email = emailField.getText();
            long phone = Long.parseLong(phoneField.getText());

            Customer customer = new Customer();
            customer.setCustomerName(name);
            customer.setEmail(email);
            customer.setPhone(phone);

            CustomerDAO dao = new CustomerDAO();
            dao.addCustomer(customer);

            JOptionPane.showMessageDialog(frame,
                    "Customer Added Successfully!");

        });

        frame.setLayout(null);
        frame.setSize(400, 350);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}