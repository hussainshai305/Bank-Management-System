package com.bank.ui;

import javax.swing.*;
import com.bank.dao.CustomerDAO;
public class DeleteCustomerFrame {

    public DeleteCustomerFrame() {

        JFrame frame = new JFrame("Delete Customer");

        JLabel idLabel = new JLabel("Customer ID:");
        idLabel.setBounds(50, 50, 100, 30);

        JTextField idField = new JTextField();
        idField.setBounds(150, 50, 150, 30);

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(150, 120, 100, 30);

        frame.add(idLabel);
        frame.add(idField);
        frame.add(deleteBtn);
        frame.add(idLabel);
        frame.add(idField);
        frame.add(deleteBtn);

        deleteBtn.addActionListener(e -> {

            int id = Integer.parseInt(idField.getText());

            CustomerDAO dao = new CustomerDAO();

            dao.deleteCustomer(id);

            JOptionPane.showMessageDialog(frame,
                    "Customer Deleted!");

        });

        frame.setLayout(null);
        frame.setSize(400, 250);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setLayout(null);
        frame.setSize(400, 250);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}