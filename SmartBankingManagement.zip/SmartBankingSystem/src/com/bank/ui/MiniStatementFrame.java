package com.bank.ui;

import javax.swing.*;
import com.bank.dao.AccountDAO;

public class MiniStatementFrame {

    public MiniStatementFrame() {

        JFrame frame = new JFrame("Mini Statement");

        JTextArea area = new JTextArea();

        AccountDAO dao = new AccountDAO();

        String data = dao.getTransactionHistory();

        area.setText(data);

        JScrollPane pane = new JScrollPane(area);

        pane.setBounds(20, 20, 450, 300);

        frame.add(pane);

        frame.setLayout(null);
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
