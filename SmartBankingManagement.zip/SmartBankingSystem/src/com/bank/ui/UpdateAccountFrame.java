package com.bank.ui;

import javax.swing.*;
import com.bank.dao.AccountDAO;
import com.bank.model.Account;

public class UpdateAccountFrame {

    public UpdateAccountFrame() {

        JFrame frame = new JFrame("Update Account");

        JLabel accLabel = new JLabel("Account No:");
        accLabel.setBounds(50, 30, 100, 30);

        JTextField accField = new JTextField();
        accField.setBounds(150, 30, 150, 30);

        JLabel custLabel = new JLabel("Customer ID:");
        custLabel.setBounds(50, 80, 100, 30);

        JTextField custField = new JTextField();
        custField.setBounds(150, 80, 150, 30);

        JLabel typeLabel = new JLabel("Account Type:");
        typeLabel.setBounds(50, 130, 100, 30);

        JTextField typeField = new JTextField();
        typeField.setBounds(150, 130, 150, 30);

        JLabel balLabel = new JLabel("Balance:");
        balLabel.setBounds(50, 180, 100, 30);

        JTextField balField = new JTextField();
        balField.setBounds(150, 180, 150, 30);

        JButton updateBtn = new JButton("Update");
        updateBtn.setBounds(150, 240, 100, 30);

        frame.add(accLabel);
        frame.add(accField);
        frame.add(custLabel);
        frame.add(custField);
        frame.add(typeLabel);
        frame.add(typeField);
        frame.add(balLabel);
        frame.add(balField);
        frame.add(updateBtn);

        updateBtn.addActionListener(e -> {

            Account account = new Account();

            account.setAccountNo(
                Long.parseLong(accField.getText()));

            account.setCustomerId(
                Integer.parseInt(custField.getText()));

            account.setAccountType(
                typeField.getText());

            account.setBalance(
                Double.parseDouble(balField.getText()));

            AccountDAO dao = new AccountDAO();

            dao.updateAccount(account);

            JOptionPane.showMessageDialog(
                frame,
                "Account Updated Successfully");

        });

        frame.setLayout(null);
        frame.setSize(400, 350);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
