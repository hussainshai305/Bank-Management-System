package com.bank.ui;

import javax.swing.*;
import com.bank.dao.CustomerDAO;
public class ViewCustomerFrame {

    public ViewCustomerFrame() {

        JFrame frame = new JFrame("View Customers");

        JTextArea area = new JTextArea();
        CustomerDAO dao = new CustomerDAO();

        String data = dao.getAllCustomers();

        area.setText(data);

        JScrollPane pane = new JScrollPane(area);

        pane.setBounds(20, 20, 450, 300);

        frame.add(pane);

        frame.setLayout(null);
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
