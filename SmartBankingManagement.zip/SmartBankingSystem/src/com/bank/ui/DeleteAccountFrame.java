package com.bank.ui;

import javax.swing.*;
import com.bank.dao.AccountDAO;

public class DeleteAccountFrame {

    public DeleteAccountFrame() {

        JFrame frame = new JFrame("Delete Account");

        JLabel accLabel = new JLabel("Account No:");
        accLabel.setBounds(50, 50, 100, 30);

        JTextField accField = new JTextField();
        accField.setBounds(150, 50, 150, 30);

        JButton deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(150, 120, 100, 30);

        deleteBtn.addActionListener(e -> {

            long accountNo =
                Long.parseLong(accField.getText());

            AccountDAO dao = new AccountDAO();

            dao.deleteAccount(accountNo);

            JOptionPane.showMessageDialog(
                frame,
                "Account Deleted Successfully"
            );

        });

        frame.add(accLabel);
        frame.add(accField);
        frame.add(deleteBtn);

        frame.setLayout(null);
        frame.setSize(400,250);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}