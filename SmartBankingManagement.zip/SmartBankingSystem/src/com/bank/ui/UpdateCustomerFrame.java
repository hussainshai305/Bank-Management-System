package com.bank.ui;

import javax.swing.*;
import com.bank.dao.CustomerDAO;
import com.bank.model.Customer;
public class UpdateCustomerFrame {

    public UpdateCustomerFrame() {

        JFrame frame = new JFrame("Update Customer");

        JLabel idLabel = new JLabel("Customer ID:");
        idLabel.setBounds(50, 30, 100, 30);

        JTextField idField = new JTextField();
        idField.setBounds(150, 30, 150, 30);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 80, 100, 30);

        JTextField nameField = new JTextField();
        nameField.setBounds(150, 80, 150, 30);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 130, 100, 30);

        JTextField emailField = new JTextField();
        emailField.setBounds(150, 130, 150, 30);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(50, 180, 100, 30);

        JTextField phoneField = new JTextField();
        phoneField.setBounds(150, 180, 150, 30);

        JButton updateBtn = new JButton("Update");
        updateBtn.setBounds(150, 240, 100, 30);

        frame.add(idLabel);
        frame.add(idField);
        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(phoneLabel);
        frame.add(phoneField);
        frame.add(updateBtn);

        updateBtn.addActionListener(e -> {

            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String email = emailField.getText();
            long phone = Long.parseLong(phoneField.getText());

            Customer customer = new Customer();

            customer.setCustomerId(id);
            customer.setCustomerName(name);
            customer.setEmail(email);
            customer.setPhone(phone);

            CustomerDAO dao = new CustomerDAO();
            dao.updateCustomer(customer);

            JOptionPane.showMessageDialog(frame,
                    "Customer Updated Successfully");
        });
        frame.setLayout(null);
        frame.setSize(400, 350);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
