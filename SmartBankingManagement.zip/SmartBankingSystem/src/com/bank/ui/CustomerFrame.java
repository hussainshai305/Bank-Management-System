package com.bank.ui;
import com.bank.ui.AddCustomerFrame;
import javax.swing.*;
import com.bank.ui.ViewCustomerFrame;
import com.bank.ui.DeleteCustomerFrame;
import com.bank.ui.UpdateCustomerFrame;
public class CustomerFrame {

    public CustomerFrame() {

        JFrame frame = new JFrame("Customer Management");

        JButton addBtn = new JButton("Add Customer");
        addBtn.setBounds(100, 30, 200, 30);

        JButton viewBtn = new JButton("View Customers");
        viewBtn.setBounds(100, 80, 200, 30);

        JButton updateBtn = new JButton("Update Customer");
        updateBtn.setBounds(100, 130, 200, 30);

        JButton deleteBtn = new JButton("Delete Customer");
        deleteBtn.setBounds(100, 180, 200, 30);

        frame.add(addBtn);
        frame.add(viewBtn);
        frame.add(updateBtn);
        frame.add(deleteBtn);
        addBtn.addActionListener(e -> {
            new AddCustomerFrame();
        });
        viewBtn.addActionListener(e -> {
            new ViewCustomerFrame();
        });
        deleteBtn.addActionListener(e -> {
            new DeleteCustomerFrame();
        });
        updateBtn.addActionListener(e -> {
            new UpdateCustomerFrame();
        });

        frame.setLayout(null);
        frame.setSize(450, 300);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}
