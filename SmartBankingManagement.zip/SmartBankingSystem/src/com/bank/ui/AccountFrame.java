package com.bank.ui;
import com.bank.ui.TransferFrame;
import javax.swing.*;
import com.bank.ui.DeleteAccountFrame;
import com.bank.ui.MiniStatementFrame;
import com.bank.ui.TransactionHistoryFrame;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
public class AccountFrame {

    public AccountFrame() {

        JFrame frame = new JFrame("Account Management");
        JLabel title = new JLabel("SMART BANKING SYSTEM");
        title.setBounds(100, 20, 350, 30);

        title.setFont(new Font("Arial", Font.BOLD, 20));

        frame.add(title);

        JButton addBtn = new JButton("Add Account");
        addBtn.setBackground(Color.BLUE);
        addBtn.setForeground(Color.WHITE);
        addBtn.setBounds(125, 70, 200, 30);
        JButton viewBtn = new JButton("View Accounts");
        viewBtn.setBackground(Color.BLUE);
        viewBtn.setForeground(Color.WHITE);
        viewBtn.setBounds(125, 120, 200, 30);
        JButton deleteBtn = new JButton("Delete Account");
        deleteBtn.setBackground(Color.BLUE);
        deleteBtn.setForeground(Color.WHITE);
        deleteBtn.setBounds(125,170,200,30);
        JButton updateBtn = new JButton("Update Account");
        updateBtn.setBackground(Color.BLUE);
        updateBtn.setForeground(Color.WHITE);
        updateBtn.setBounds(125, 220, 200, 30);
        JButton depositBtn = new JButton("Deposit Money");
        depositBtn.setBackground(Color.BLUE);
        depositBtn.setForeground(Color.WHITE);
        depositBtn.setBounds(125,270,200,30);
        JButton withdrawBtn =new JButton("Withdraw Money");
        withdrawBtn .setBackground(Color.BLUE);
        withdrawBtn .setForeground(Color.WHITE);
        withdrawBtn.setBounds(125,320,200,30);
        JButton balanceBtn = new JButton("Balance Enquiry");
        balanceBtn.setBackground(Color.BLUE);
        balanceBtn.setForeground(Color.WHITE);

        balanceBtn.setBounds(125,370,200,30);
        JButton transferBtn =new JButton("Transfer Money");
        transferBtn.setBackground(Color.BLUE);
        transferBtn.setForeground(Color.WHITE);

        transferBtn.setBounds(125, 420, 200, 30);

        JButton statementBtn =new JButton("Mini Statement");
        statementBtn.setBackground(Color.BLUE);
        statementBtn.setForeground(Color.WHITE);

        statementBtn.setBounds(125, 470, 200, 30);
        
        JButton historyBtn = new JButton("Transaction History");
        historyBtn.setBackground(Color.BLUE);
        historyBtn.setForeground(Color.WHITE);
        historyBtn.setBounds(125, 520, 200, 30);

        
        
        frame.add(addBtn);
        frame.add(viewBtn);
        frame.add(deleteBtn);
        frame.add(updateBtn);
        frame.add(depositBtn);
        frame.add(withdrawBtn);
        frame.add(balanceBtn);
        frame.add(transferBtn);
        frame.add(statementBtn);
        frame.add(historyBtn);
        
        
        addBtn.addActionListener(e -> {
            new AddAccountFrame();
        });
        viewBtn.addActionListener(e -> {
            new ViewAccountFrame();
        });
        deleteBtn.addActionListener(e -> {

            new DeleteAccountFrame();

        });
        updateBtn.addActionListener(e -> {
            new UpdateAccountFrame();
        });
        depositBtn.addActionListener(e -> {
            new DepositFrame();
        });
        withdrawBtn.addActionListener(e -> {
            new WithdrawFrame();
        });
        balanceBtn.addActionListener(e -> {

            new BalanceEnquiryFrame();

        });
        transferBtn.addActionListener(e -> {

            new TransferFrame();

        });
        statementBtn.addActionListener(e -> {

            new MiniStatementFrame();

        });
        historyBtn.addActionListener(e -> {

            new TransactionHistoryFrame();

        });

        frame.setLayout(null);
        frame.setSize(550, 700);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
    }
}