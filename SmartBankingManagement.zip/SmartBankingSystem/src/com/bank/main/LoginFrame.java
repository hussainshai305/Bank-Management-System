package com.bank.main;
import com.bank.dao.LoginDAO;
import javax.swing.*;
import java.awt.*;
import com.bank.ui.DashboardFrame;

public class LoginFrame {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Smart Banking Login");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 50, 100, 30);

        JTextField userField = new JTextField();
        userField.setBounds(150, 50, 150, 30);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(50, 100, 100, 30);

        JPasswordField passField = new JPasswordField();
        passField.setBounds(150, 100, 150, 30);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(150, 160, 100, 30);

        frame.add(userLabel);
        frame.add(userField);
        frame.add(passLabel);
        frame.add(passField);
        frame.add(loginBtn);
        
        loginBtn.addActionListener(e -> {

            String username = userField.getText();
            String password = new String(passField.getPassword());

            LoginDAO loginDao = new LoginDAO();

            if(loginDao.login(username, password)) {

                JOptionPane.showMessageDialog(frame,
                        "Login Successful!");
                frame.dispose();
                new DashboardFrame();

            } else {

                JOptionPane.showMessageDialog(frame,
                        "Invalid Username or Password!");

            }

        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }
}
