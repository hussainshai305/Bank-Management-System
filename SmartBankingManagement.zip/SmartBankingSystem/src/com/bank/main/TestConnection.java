package com.bank.main;

import com.bank.dao.LoginDAO;
import java.util.Scanner;
import com.bank.model.Account;
import com.bank.dao.AccountDAO;
import com.bank.dao.CustomerDAO;
import com.bank.model.Customer;

public class TestConnection {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Username:");
        String username=sc.next();
        System.out.println("Password:");
        String password=sc.next();
        LoginDAO loginDao = new LoginDAO();

        if(!loginDao.login(username, password)) {
            System.out.println("Invalid Login!");
            return;
        }

        System.out.println("Login Successful!");
        CustomerDAO dao = new CustomerDAO();

        while (true) {

            System.out.println("\n===== SMART BANKING SYSTEM =====");
            System.out.println("1.  Add Customer");
            System.out.println("2.  View Customers");
            System.out.println("3.  Update Customer");
            System.out.println("4.  Delete Customer");
            System.out.println("5.  Exit");
            System.out.println("6.  Create account");
            System.out.println("7.  Deposit money");
            System.out.println("8.  Withdraw money");
            System.out.println("9.  Check balance");
            System.out.println("10. Fund transfer");
            System.out.println("11. Mini statement");
            System.out.println("12. Change Password");
            System.out.println("13. Search Account");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            switch (choice) {

            case 1:
                Customer c = new Customer();

                System.out.print("Enter Name: ");
                sc.nextLine();
                c.setCustomerName(sc.nextLine());

                System.out.print("Enter Email: ");
                c.setEmail(sc.nextLine());

                System.out.print("Enter Phone: ");
                c.setPhone(sc.nextLong());
                
                System.out.println("Enter initial balance: ");
                c.setBalance(sc.nextDouble());

                dao.addCustomer(c);
                break;

            case 2:
                dao.viewCustomers();
                break;

            case 3:
                Customer u = new Customer();

                System.out.print("Enter Customer ID: ");
                u.setCustomerId(sc.nextInt());

                sc.nextLine();

                System.out.print("Enter New Name: ");
                u.setCustomerName(sc.nextLine());

                System.out.print("Enter New Email: ");
                u.setEmail(sc.nextLine());

                System.out.print("Enter New Phone: ");
                u.setPhone(sc.nextLong());

                dao.updateCustomer(u);
                break;

            case 4:
                System.out.print("Enter Customer ID to Delete: ");
                int id = sc.nextInt();

                dao.deleteCustomer(id);
                break;

            case 5:
                System.out.println("Thank You!");
                sc.close();
                System.exit(0);
            case 6:

                Account a = new Account();

                System.out.print("Enter Customer ID: ");
                a.setCustomerId(sc.nextInt());

                System.out.print("Enter Account Type (Savings/Current): ");
                sc.nextLine();
                a.setAccountType(sc.nextLine());

                System.out.print("Enter Initial Balance: ");
                a.setBalance(sc.nextDouble());

                AccountDAO accountDao = new AccountDAO();
                accountDao.createAccount(a);

                break;
            case 7:

                System.out.print("Enter Account Number: ");
                int accountNo = sc.nextInt();

                System.out.print("Enter Amount to Deposit: ");
                double amount = sc.nextDouble();
                AccountDAO dao2=new AccountDAO();
                dao2.depositMoney(accountNo, amount);

                break;
            case 8:

                System.out.print("Enter Account Number: ");
                int accNo = sc.nextInt();

                System.out.print("Enter Amount to Withdraw: ");
                double amt = sc.nextDouble();

                AccountDAO dao3=new AccountDAO();
                dao3.withdrawMoney(accNo, amt);

                break;
            case 9:

                System.out.print("Enter Account Number: ");
                int accNo1 = sc.nextInt();

                AccountDAO dao4 = new AccountDAO();

                dao4.checkBalance(accNo1);

                break;
            case 10:

                System.out.print("From Account Number: ");
                int fromAcc = sc.nextInt();

                System.out.print("To Account Number: ");
                int toAcc = sc.nextInt();

                System.out.print("Amount: ");
                double transferAmount = sc.nextDouble();

                AccountDAO dao5 = new AccountDAO();
                dao5.transferMoney(fromAcc, toAcc, transferAmount);

                break;
            case 11:

                System.out.print("Enter Account Number: ");
                int accountNo2 = sc.nextInt();

                AccountDAO dao6 = new AccountDAO();

                dao6.miniStatement(accountNo2);

                break;
            case 12:

                System.out.print("Enter Username: ");
                String uname = sc.next();

                System.out.print("Enter New Password: ");
                String newPass = sc.next();

                LoginDAO loginDao2 = new LoginDAO();

                loginDao2.changePassword(uname, newPass);

                break;
            case 13:

                System.out.print("Enter Account Number: ");
                int searchAcc = sc.nextInt();

                AccountDAO dao7 = new AccountDAO();

                dao7 .searchAccount(searchAcc);

                break;

            default:
                System.out.println("Invalid Choice!");
            }
        }
    }
}